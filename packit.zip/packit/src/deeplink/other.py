from ui.bulletin import BulletinHelper
from client_utils import get_last_fragment
from android_utils import log


def handle(url):
    if url == "tg://packit?other":
        try:
            currentFragment = get_last_fragment()
            BulletinHelper.show_success("Other settings triggered", currentFragment)
        except Exception as e:
            log(f"[PackIt] Error: {e}")
