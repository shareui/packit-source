from ui.settings import Header, Input, Text, Divider
from ui.alert import AlertDialogBuilder
from elyx import strings, settings
from client_utils import get_last_fragment


class CommandSettings:
    def __init__(self):
        pass
    
    def _showCommandInfo(self, title, description, usage):
        fragment = get_last_fragment()
        if not fragment:
            return
        
        activity = fragment.getParentActivity()
        if not activity:
            return
        
        builder = AlertDialogBuilder(activity)
        builder.set_title(title)
        builder.set_message(f"{description}\n\n{usage}")
        builder.set_positive_button("OK", lambda b, w: b.dismiss())
        builder.show()
    
    def _showAllCommandsInfo(self, view):
        info_text = """Info - shows plugin details
Search - finds plugins in repositories
Install - downloads and installs plugin
Uninstall - removes installed plugin
Update - refreshes repository cache
Upgrade - updates plugin to latest version
Plugin List - shows all available plugins
Repository List - shows enabled repositories
Share - shares plugin download link

Add -r flag to auto-restart after install/uninstall/upgrade"""
        
        fragment = get_last_fragment()
        if not fragment:
            return
        
        activity = fragment.getParentActivity()
        if not activity:
            return
        
        builder = AlertDialogBuilder(activity)
        builder.set_title("Commands Overview")
        builder.set_message(info_text)
        builder.set_positive_button("OK", lambda b, w: b.dismiss())
        builder.show()
    
    def build(self):
        return [
            Header(text=strings.command_settings),
            
            Input(
                key="cmd_info",
                text=strings.cmd_info,
                default=settings.get("cmd_info", "packit info"),
                icon="msg_info"
            ),
            Input(
                key="cmd_search",
                text=strings.cmd_search,
                default=settings.get("cmd_search", "packit search"),
                icon="msg_search"
            ),
            
            Divider(),
            Header(text="Installation"),
            
            Input(
                key="cmd_install",
                text=strings.cmd_install,
                default=settings.get("cmd_install", "packit install"),
                icon="msg_download"
            ),
            Input(
                key="cmd_uninstall",
                text=strings.cmd_uninstall,
                default=settings.get("cmd_uninstall", "packit uninstall"),
                icon="msg_delete"
            ),
            Input(
                key="cmd_upgrade",
                text="Upgrade command",
                default=settings.get("cmd_upgrade", "packit upgrade"),
                icon="gift_upgrade"
            ),
            
            Divider(),
            Header(text="Repository Management"),
            
            Input(
                key="cmd_update",
                text="Update command",
                default=settings.get("cmd_update", "packit update"),
                icon="msg_retry"
            ),
            Input(
                key="cmd_pluginlist",
                text=strings.cmd_pluginlist,
                default=settings.get("cmd_pluginlist", "packit pluginlist"),
                icon="msg_list"
            ),
            Input(
                key="cmd_repolist",
                text=strings.cmd_repolist,
                default=settings.get("cmd_repolist", "packit repolist"),
                icon="msg_folders"
            ),
            
            Divider(),
            Header(text="Sharing"),
            
            Input(
                key="cmd_share",
                text=strings.cmd_share,
                default=settings.get("cmd_share", "packit share"),
                icon="msg_share"
            ),
            
            Divider(),
            
            Text(
                text="View all commands help",
                icon="msg_help",
                accent=True,
                on_click=self._showAllCommandsInfo
            )
        ]
