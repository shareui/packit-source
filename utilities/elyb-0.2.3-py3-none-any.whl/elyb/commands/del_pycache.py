import os
import shutil

from elyb.settings import findSettingsPath, readSettings


def runDelPycache() -> None:
    settingsPath = findSettingsPath()
    settings = readSettings(settingsPath)
    pluginRoot = settings.get("pluginRoot")

    if not pluginRoot or not os.path.isdir(pluginRoot):
        print(f"error: pluginRoot not found: {pluginRoot}")
        return

    removed = 0
    for dirpath, dirnames, _ in os.walk(pluginRoot):
        if "__pycache__" in dirnames:
            shutil.rmtree(os.path.join(dirpath, "__pycache__"))
            dirnames.remove("__pycache__")
            removed += 1

    if removed:
        print(f"removed {removed} __pycache__ director{'y' if removed == 1 else 'ies'}")
    else:
        print("no __pycache__ found")
