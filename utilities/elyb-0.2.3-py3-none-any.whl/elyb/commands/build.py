import os
import shutil
import subprocess
import sys
import zipfile

from elyb.settings import findSettingsPath, readSettings, loadRefmap, loadMeta

RED = "\033[31m"
RESET = "\033[0m"


def buildOutputName(template: str, meta: dict, zipFormat: str) -> str:
    # replace {key} placeholders with values from meta; unknown keys stay as-is
    result = template
    for key, value in meta.items():
        result = result.replace(f"{{{key}}}", str(value))
    return f"{result}.{zipFormat}"


def resolveOutputPath(outputDir: str, filename: str) -> str:
    base = os.path.join(outputDir, filename)
    if not os.path.exists(base):
        return base
    name, ext = os.path.splitext(filename)
    i = 1
    while True:
        candidate = os.path.join(outputDir, f"{name}-duplicate.{i}{ext}")
        if not os.path.exists(candidate):
            return candidate
        i += 1


def findPython311() -> str | None:
    # on Windows: try py launcher first, then direct names
    candidates = ["python3.11", "python3", "python"]
    if sys.platform == "win32":
        candidates = ["py", "python3.11", "python"]

    for candidate in candidates:
        try:
            args = [candidate]
            if candidate == "py":
                args = ["py", "-3.11"]
            result = subprocess.run(
                args + ["--version"],
                capture_output=True, text=True
            )
            if result.returncode == 0 and "3.11" in result.stdout + result.stderr:
                return " ".join(args)
        except FileNotFoundError:
            continue
    return None


def removePycache(rootDir: str) -> None:
    for dirpath, dirnames, _ in os.walk(rootDir):
        if "__pycache__" in dirnames:
            shutil.rmtree(os.path.join(dirpath, "__pycache__"))
            dirnames.remove("__pycache__")


def compilePyFiles(python311Cmd: str, pyFiles: list[str], verbose: bool) -> dict[str, str]:
    # compiles each .py file via python3.11 -m py_compile
    # returns mapping: abs source path -> abs .pyc path
    result = {}
    args = python311Cmd.split() + ["-m", "py_compile"]

    for srcAbs in pyFiles:
        proc = subprocess.run(args + [srcAbs], capture_output=True, text=True)
        if proc.returncode != 0:
            print(f"error: failed to compile {srcAbs}:\n{proc.stderr}", file=sys.stderr)
            sys.exit(1)

        srcDir = os.path.dirname(srcAbs)
        baseName = os.path.splitext(os.path.basename(srcAbs))[0]
        pycacheDir = os.path.join(srcDir, "__pycache__")

        # find the cpython-311 .pyc among compiled files
        pycPath = None
        if os.path.isdir(pycacheDir):
            for entry in os.listdir(pycacheDir):
                if entry.startswith(baseName + ".cpython-311") and entry.endswith(".pyc"):
                    pycPath = os.path.join(pycacheDir, entry)
                    break

        if not pycPath:
            print(f"error: .pyc not found after compiling {srcAbs}", file=sys.stderr)
            sys.exit(1)

        if verbose:
            print(f"{os.path.basename(srcAbs)} compiled successfully!")

        result[srcAbs] = pycPath
    return result


def isExcluded(relPath: str, excludedPaths: list) -> bool:
    norm = os.path.normpath(relPath)
    for p in excludedPaths:
        normP = os.path.normpath(p)
        if norm == normP or norm.startswith(normP + os.sep):
            return True
    return False


def collectFiles(roots: list, excludedPaths: list) -> list:
    # returns list of (absPath, arcName, isDir)
    result = []
    for root in roots:
        arcBase = os.path.dirname(os.path.normpath(root))
        for dirpath, dirnames, filenames in os.walk(root):
            relDirCwd = os.path.normpath(os.path.relpath(dirpath, "."))
            relDirArc = os.path.normpath(os.path.relpath(dirpath, arcBase))

            if isExcluded(relDirCwd, excludedPaths):
                dirnames.clear()
                continue

            dirnames[:] = [
                d for d in dirnames
                if not isExcluded(os.path.join(relDirCwd, d), excludedPaths)
                and d != "__pycache__"
            ]

            # add directory entry so elyxcore can find "assets/" in archive namelist
            result.append((dirpath, relDirArc + "/", True))

            for filename in filenames:
                absFile = os.path.join(dirpath, filename)
                relFileCwd = os.path.normpath(os.path.relpath(absFile, "."))
                arcName = os.path.normpath(os.path.join(relDirArc, filename))
                if not isExcluded(relFileCwd, excludedPaths):
                    result.append((absFile, arcName, False))
    return result


def applyReleaseCompilation(
    files: list,
    pluginRoot: str,
    releaseIgnore: list,
    python311Cmd: str,
    verbose: bool,
) -> list:
    # replaces .py entries with compiled .pyc, skipping releaseIgnore paths
    # releaseIgnore paths are relative to cwd, same as how add-release stores them
    pluginRootNorm = os.path.normpath(pluginRoot)

    pyFilesToCompile = []
    for absPath, arcName, isDir in files:
        if isDir or not absPath.endswith(".py"):
            continue
        # only compile files inside pluginRoot
        absNorm = os.path.normpath(absPath)
        if absNorm != pluginRootNorm and not absNorm.startswith(pluginRootNorm + os.sep):
            continue
        relFromCwd = os.path.normpath(os.path.relpath(absPath, "."))
        if isExcluded(relFromCwd, releaseIgnore):
            continue
        pyFilesToCompile.append(absPath)

    if not pyFilesToCompile:
        return files

    pycMap = compilePyFiles(python311Cmd, pyFilesToCompile, verbose)

    result = []
    for absPath, arcName, isDir in files:
        if not isDir and absPath in pycMap:
            # swap .py -> .pyc, keep same arc path but change extension
            pycAbs = pycMap[absPath]
            pycArcName = os.path.splitext(arcName)[0] + ".pyc"
            result.append((pycAbs, pycArcName, False))
        else:
            result.append((absPath, arcName, isDir))
    return result


def writeArchive(outputPath: str, files: list, compression: int, password) -> None:
    if password is not None:
        try:
            import pyzipper
        except ImportError:
            print("error: --pass requires pyzipper: pip install pyzipper", file=sys.stderr)
            sys.exit(1)

        with pyzipper.AESZipFile(outputPath, "w", compression=pyzipper.ZIP_DEFLATED, encryption=pyzipper.WZ_AES) as zf:
            zf.setpassword(password.encode())
            zf.compresslevel = compression
            for absPath, arcName, isDir in files:
                if isDir:
                    zf.mkdir(arcName)
                else:
                    zf.write(absPath, arcName)
        return

    with zipfile.ZipFile(outputPath, "w", zipfile.ZIP_DEFLATED, compresslevel=compression) as zf:
        for absPath, arcName, isDir in files:
            if isDir:
                dirInfo = zipfile.ZipInfo(arcName)
                zf.writestr(dirInfo, "")
            else:
                zf.write(absPath, arcName)


def runBuild(noAssets: bool, compression: int, password, additionalPaths: list, dryRun: bool, release: bool, verbose: bool) -> None:
    if not (0 <= compression <= 9):
        print("error: --compression must be between 0 and 9", file=sys.stderr)
        sys.exit(1)

    settingsPath = findSettingsPath()
    settings = readSettings(settingsPath)

    refmapPath = settings.get("refmap")
    outputDir = settings.get("outputDir")
    zipFormat = settings.get("zipFormat", "zip")
    pluginRoot = settings.get("pluginRoot")

    if not refmapPath or not os.path.isfile(refmapPath):
        print(f"error: refmap not found: {refmapPath}", file=sys.stderr)
        sys.exit(1)

    refmap = loadRefmap(refmapPath)

    try:
        metainfoPath, meta = loadMeta(refmap)
    except (ValueError, FileNotFoundError) as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)

    pluginId = meta.get("id")
    version = meta.get("version")

    if not pluginId:
        print("error: 'id' missing in metainfo", file=sys.stderr)
        sys.exit(1)

    if not version:
        print("error: 'version' missing in metainfo", file=sys.stderr)
        sys.exit(1)

    for p in additionalPaths:
        if not os.path.exists(p):
            print(f"error: additional path does not exist: {p}", file=sys.stderr)
            sys.exit(1)

    python311Cmd = None
    if release:
        python311Cmd = findPython311()
        if not python311Cmd:
            print(f"{RED}Python 3.11 not found!{RESET}", file=sys.stderr)
            sys.exit(1)

    excludedPaths = settings.get("optionalAssets", []) if noAssets else []
    roots = [pluginRoot] + additionalPaths
    files = collectFiles(roots, excludedPaths)
    files.append((refmapPath, os.path.normpath(refmapPath), False))

    if release:
        releaseIgnore = settings.get("releaseIgnore", [])
        files = applyReleaseCompilation(files, pluginRoot, releaseIgnore, python311Cmd, verbose)

    if dryRun:
        fileEntries = [(arc, isDir) for _, arc, isDir in files]
        fileCount = sum(1 for _, isDir in fileEntries if not isDir)
        print(f"dry-run: {fileCount} files would be packed")
        for arcName, isDir in fileEntries:
            print(f"  {'[dir] ' if isDir else ''}{arcName}")
        return

    os.makedirs(outputDir, exist_ok=True)
    if release:
        buildNameTemplate = settings.get("buildNameRelease") or settings.get("buildName", "{id}-{version}")
    else:
        buildNameTemplate = settings.get("buildName", "{id}-{version}")
    outputFilename = buildOutputName(buildNameTemplate, meta, zipFormat)
    outputPath = resolveOutputPath(outputDir, outputFilename)
    writeArchive(outputPath, files, compression, password)
    if release:
        removePycache(pluginRoot)
    print(f"built: {outputPath}")
