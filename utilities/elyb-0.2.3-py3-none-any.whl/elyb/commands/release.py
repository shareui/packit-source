import os
import sys

from elyb.settings import findSettingsPath, readSettings, writeSettings


def runAddRelease(path: str) -> None:
    path = os.path.normpath(path)
    settingsPath = findSettingsPath()
    data = readSettings(settingsPath)

    releases: list = data.setdefault("releaseIgnore", [])

    if path in releases:
        print(f"already in releaseIgnore: {path}")
        return

    releases.append(path)
    writeSettings(settingsPath, data)
    print(f"added to releaseIgnore: {path}")


def runDelRelease(path: str) -> None:
    path = os.path.normpath(path)
    settingsPath = findSettingsPath()
    data = readSettings(settingsPath)

    releases: list = data.get("releaseIgnore", [])

    if path not in releases:
        print(f"error: not in releaseIgnore: {path}", file=sys.stderr)
        sys.exit(1)

    releases.remove(path)
    data["releaseIgnore"] = releases
    writeSettings(settingsPath, data)
    print(f"removed from releaseIgnore: {path}")
