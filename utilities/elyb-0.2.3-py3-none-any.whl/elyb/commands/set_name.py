from elyb.settings import findSettingsPath, readSettings, writeSettings


def runSetName(template: str, release: bool) -> None:
    settingsPath = findSettingsPath()
    settings = readSettings(settingsPath)
    key = "buildNameRelease" if release else "buildName"
    settings[key] = template
    writeSettings(settingsPath, settings)
    print(f"{key} set: {template}")
