import os

from elyb.settings import findSettingsPath, readSettings, loadRefmap, loadMeta


def runInfo() -> None:
    settingsPath = findSettingsPath()
    settings = readSettings(settingsPath)

    refmapPath = settings.get("refmap", "")
    pluginRoot = settings.get("pluginRoot", "")
    outputDir = settings.get("outputDir", "")
    zipFormat = settings.get("zipFormat", "zip")
    optionalAssets = settings.get("optionalAssets", [])

    pluginId = "unknown"
    version = "unknown"
    name = ""
    author = ""

    if refmapPath and os.path.isfile(refmapPath):
        try:
            refmap = loadRefmap(refmapPath)
            _, meta = loadMeta(refmap)
            pluginId = meta.get("id", "unknown")
            version = meta.get("version", "unknown")
            name = meta.get("name", "")
            author = meta.get("author", "")
        except Exception:
            pass

    print(f"plugin:      {name or pluginId}")
    print(f"id:          {pluginId}")
    print(f"version:     {version}")
    if author:
        print(f"author:      {author}")
    print(f"pluginRoot:  {pluginRoot}")
    print(f"refmap:      {refmapPath}")
    print(f"outputDir:   {outputDir}")
    print(f"zipFormat:   {zipFormat}")

    if optionalAssets:
        print(f"optionalAssets ({len(optionalAssets)}):")
        for p in optionalAssets:
            exists = os.path.exists(p)
            marker = "" if exists else " (missing)"
            print(f"  {p}{marker}")
    else:
        print("optionalAssets: none")

    if outputDir and os.path.isdir(outputDir):
        builds = sorted(os.listdir(outputDir))
        if builds:
            print(f"builds ({len(builds)}):")
            for b in builds:
                print(f"  {b}")
        else:
            print("builds: none")
