import os
import re
import sys

from elyb.settings import findSettingsPath, readSettings


def isDuplicate(filename: str) -> bool:
    return bool(re.search(r"-duplicate\.\d+\.", filename))


def runClean(duplicatesOnly: bool) -> None:
    settingsPath = findSettingsPath()
    settings = readSettings(settingsPath)

    outputDir = settings.get("outputDir")
    if not outputDir:
        print("error: 'outputDir' not set in settings", file=sys.stderr)
        sys.exit(1)

    if not os.path.isdir(outputDir):
        print(f"error: outputDir does not exist: {outputDir}", file=sys.stderr)
        sys.exit(1)

    files = sorted(os.listdir(outputDir))
    targets = [f for f in files if duplicatesOnly and isDuplicate(f) or not duplicatesOnly]

    if not targets:
        print("nothing to clean")
        return

    for filename in targets:
        path = os.path.join(outputDir, filename)
        os.remove(path)
        print(f"removed: {path}")

    print(f"cleaned {len(targets)} file(s)")
