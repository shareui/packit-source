import os
import sys
import zipfile

from elyb.settings import findSettingsPath, readSettings, loadRefmap, loadMeta


def resolveOutputPath(outputDir: str, pluginId: str, version: str, zipFormat: str) -> str:
    base = os.path.join(outputDir, f"{pluginId}-{version}.{zipFormat}")
    if not os.path.exists(base):
        return base
    i = 1
    while True:
        candidate = os.path.join(outputDir, f"{pluginId}-{version}-duplicate.{i}.{zipFormat}")
        if not os.path.exists(candidate):
            return candidate
        i += 1


def isExcluded(relPath: str, excludedPaths: list) -> bool:
    norm = os.path.normpath(relPath)
    for p in excludedPaths:
        normP = os.path.normpath(p)
        if norm == normP or norm.startswith(normP + os.sep):
            return True
    return False


def collectFiles(roots: list, excludedPaths: list) -> list:
    # returns list of (absPath, arcName, isDir)
    result = []
    for root in roots:
        arcBase = os.path.dirname(os.path.normpath(root))
        for dirpath, dirnames, filenames in os.walk(root):
            relDirCwd = os.path.normpath(os.path.relpath(dirpath, "."))
            relDirArc = os.path.normpath(os.path.relpath(dirpath, arcBase))

            if isExcluded(relDirCwd, excludedPaths):
                dirnames.clear()
                continue

            dirnames[:] = [
                d for d in dirnames
                if not isExcluded(os.path.join(relDirCwd, d), excludedPaths)
            ]

            # add directory entry so elyxcore can find "assets/" in archive namelist
            result.append((dirpath, relDirArc + "/", True))

            for filename in filenames:
                absFile = os.path.join(dirpath, filename)
                relFileCwd = os.path.normpath(os.path.relpath(absFile, "."))
                arcName = os.path.normpath(os.path.join(relDirArc, filename))
                if not isExcluded(relFileCwd, excludedPaths):
                    result.append((absFile, arcName, False))
    return result


def writeArchive(outputPath: str, files: list, compression: int, password) -> None:
    if password is not None:
        try:
            import pyzipper
        except ImportError:
            print("error: --pass requires pyzipper: pip install pyzipper", file=sys.stderr)
            sys.exit(1)

        with pyzipper.AESZipFile(outputPath, "w", compression=pyzipper.ZIP_DEFLATED, encryption=pyzipper.WZ_AES) as zf:
            zf.setpassword(password.encode())
            zf.compresslevel = compression
            for absPath, arcName, isDir in files:
                if isDir:
                    zf.mkdir(arcName)
                else:
                    zf.write(absPath, arcName)
        return

    with zipfile.ZipFile(outputPath, "w", zipfile.ZIP_DEFLATED, compresslevel=compression) as zf:
        for absPath, arcName, isDir in files:
            if isDir:
                dirInfo = zipfile.ZipInfo(arcName)
                zf.writestr(dirInfo, "")
            else:
                zf.write(absPath, arcName)


def runBuild(noAssets: bool, compression: int, password, additionalPaths: list, dryRun: bool) -> None:
    if not (0 <= compression <= 9):
        print("error: --compression must be between 0 and 9", file=sys.stderr)
        sys.exit(1)

    settingsPath = findSettingsPath()
    settings = readSettings(settingsPath)

    refmapPath = settings.get("refmap")
    outputDir = settings.get("outputDir")
    zipFormat = settings.get("zipFormat", "zip")
    pluginRoot = settings.get("pluginRoot")

    if not refmapPath or not os.path.isfile(refmapPath):
        print(f"error: refmap not found: {refmapPath}", file=sys.stderr)
        sys.exit(1)

    refmap = loadRefmap(refmapPath)

    try:
        metainfoPath, meta = loadMeta(refmap)
    except (ValueError, FileNotFoundError) as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)

    pluginId = meta.get("id")
    version = meta.get("version")

    if not pluginId:
        print("error: 'id' missing in metainfo", file=sys.stderr)
        sys.exit(1)

    if not version:
        print("error: 'version' missing in metainfo", file=sys.stderr)
        sys.exit(1)

    for p in additionalPaths:
        if not os.path.exists(p):
            print(f"error: additional path does not exist: {p}", file=sys.stderr)
            sys.exit(1)

    excludedPaths = settings.get("optionalAssets", []) if noAssets else []
    roots = [pluginRoot] + additionalPaths
    files = collectFiles(roots, excludedPaths)
    files.append((refmapPath, os.path.normpath(refmapPath), False))

    if dryRun:
        fileEntries = [(arc, isDir) for _, arc, isDir in files]
        fileCount = sum(1 for _, isDir in fileEntries if not isDir)
        print(f"dry-run: {fileCount} files would be packed")
        for arcName, isDir in fileEntries:
            print(f"  {'[dir] ' if isDir else ''}{arcName}")
        return

    os.makedirs(outputDir, exist_ok=True)
    outputPath = resolveOutputPath(outputDir, pluginId, version, zipFormat)
    writeArchive(outputPath, files, compression, password)
    print(f"built: {outputPath}")
