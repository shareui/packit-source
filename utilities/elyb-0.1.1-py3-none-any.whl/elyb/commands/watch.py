import os
import sys
import time
import hashlib

from elyb.settings import findSettingsPath, readSettings
from elyb.commands.build import runBuild


def hashDir(root: str, excludedPaths: list) -> str:
    h = hashlib.md5()
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames.sort()
        for filename in sorted(filenames):
            absFile = os.path.join(dirpath, filename)
            relFile = os.path.normpath(os.path.relpath(absFile, "."))
            skip = False
            for p in excludedPaths:
                normP = os.path.normpath(p)
                if relFile == normP or relFile.startswith(normP + os.sep):
                    skip = True
                    break
            if skip:
                continue
            h.update(relFile.encode())
            try:
                stat = os.stat(absFile)
                h.update(str(stat.st_mtime_ns).encode())
                h.update(str(stat.st_size).encode())
            except OSError:
                pass
    return h.hexdigest()


def runWatch(noAssets: bool, compression: int, interval: int) -> None:
    settingsPath = findSettingsPath()
    settings = readSettings(settingsPath)

    pluginRoot = settings.get("pluginRoot")
    if not pluginRoot or not os.path.isdir(pluginRoot):
        print(f"error: pluginRoot does not exist: {pluginRoot}", file=sys.stderr)
        sys.exit(1)

    excludedPaths = settings.get("optionalAssets", []) if noAssets else []

    print(f"watching: {pluginRoot} (interval: {interval}s, ctrl+c to stop)")

    lastHash = hashDir(pluginRoot, excludedPaths)

    # build once on start
    runBuild(noAssets=noAssets, compression=compression, password=None, additionalPaths=[], dryRun=False)

    try:
        while True:
            time.sleep(interval)
            currentHash = hashDir(pluginRoot, excludedPaths)
            if currentHash != lastHash:
                lastHash = currentHash
                print("change detected, rebuilding...")
                runBuild(noAssets=noAssets, compression=compression, password=None, additionalPaths=[], dryRun=False)
    except KeyboardInterrupt:
        print("\nstopped")
