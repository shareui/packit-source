import os
import sys

from elyb.settings import getSettingsPath, writeSettings


def runInit(pluginRoot: str, refmap: str, outputDir: str, zipFormat: str) -> None:
    pluginRoot = os.path.normpath(pluginRoot)
    refmap = os.path.normpath(refmap)
    outputDir = os.path.normpath(outputDir)

    if not os.path.isdir(pluginRoot):
        print(f"error: directory does not exist: {pluginRoot}", file=sys.stderr)
        sys.exit(1)

    if not os.path.isfile(refmap):
        print(f"error: refmap file does not exist: {refmap}", file=sys.stderr)
        sys.exit(1)

    os.makedirs(".elyb", exist_ok=True)

    settingsPath = getSettingsPath(".")

    if os.path.isfile(settingsPath):
        print(f"error: already initialized ({settingsPath})", file=sys.stderr)
        sys.exit(1)

    data = {
        "pluginRoot": pluginRoot,
        "refmap": refmap,
        "outputDir": outputDir,
        "zipFormat": zipFormat,
        "optionalAssets": []
    }

    writeSettings(settingsPath, data)
    print(f"initialized: {settingsPath}")
