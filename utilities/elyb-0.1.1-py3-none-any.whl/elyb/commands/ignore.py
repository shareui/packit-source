import os
import sys

from elyb.settings import findSettingsPath, readSettings, writeSettings


def runAddIgnore(path: str) -> None:
    path = os.path.normpath(path)
    settingsPath = findSettingsPath()
    data = readSettings(settingsPath)

    assets: list = data.setdefault("optionalAssets", [])

    if path in assets:
        print(f"already in optionalAssets: {path}")
        return

    assets.append(path)
    writeSettings(settingsPath, data)
    print(f"added to optionalAssets: {path}")


def runDelIgnore(path: str) -> None:
    path = os.path.normpath(path)
    settingsPath = findSettingsPath()
    data = readSettings(settingsPath)

    assets: list = data.get("optionalAssets", [])

    if path not in assets:
        print(f"error: not in optionalAssets: {path}", file=sys.stderr)
        sys.exit(1)

    assets.remove(path)
    data["optionalAssets"] = assets
    writeSettings(settingsPath, data)
    print(f"removed from optionalAssets: {path}")
