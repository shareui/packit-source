import os
import sys

from elyb.settings import findSettingsPath, readSettings, loadRefmap, loadMeta


def runValidate() -> None:
    settingsPath = findSettingsPath()
    settings = readSettings(settingsPath)

    errors = []
    warnings = []

    pluginRoot = settings.get("pluginRoot")
    refmapPath = settings.get("refmap")
    outputDir = settings.get("outputDir")

    if not pluginRoot:
        errors.append("settings: 'pluginRoot' missing")
    elif not os.path.isdir(pluginRoot):
        errors.append(f"pluginRoot does not exist: {pluginRoot}")

    if not refmapPath:
        errors.append("settings: 'refmap' missing")
    elif not os.path.isfile(refmapPath):
        errors.append(f"refmap does not exist: {refmapPath}")
    else:
        try:
            refmap = loadRefmap(refmapPath)
        except Exception as e:
            errors.append(f"refmap parse error: {e}")
            refmap = None

        if refmap is not None:
            try:
                metainfoPath, meta = loadMeta(refmap)
            except FileNotFoundError as e:
                errors.append(f"metainfo not found: {e}")
                meta = None
            except ValueError as e:
                errors.append(str(e))
                meta = None

            if meta is not None:
                if not meta.get("id"):
                    errors.append("metainfo: 'id' missing")
                if not meta.get("version"):
                    errors.append("metainfo: 'version' missing")
                if not meta.get("name"):
                    warnings.append("metainfo: 'name' missing")
                if not meta.get("author"):
                    warnings.append("metainfo: 'author' missing")

            # check all paths referenced in refmap exist
            for key, path in refmap.items():
                if key == "metainfo":
                    continue
                if isinstance(path, str) and not os.path.exists(path):
                    warnings.append(f"refmap '{key}' path does not exist: {path}")

    for p in settings.get("optionalAssets", []):
        if not os.path.exists(p):
            warnings.append(f"optionalAsset path does not exist: {p}")

    if not outputDir:
        warnings.append("settings: 'outputDir' missing")

    for w in warnings:
        print(f"warning: {w}")

    for e in errors:
        print(f"error: {e}", file=sys.stderr)

    if errors:
        sys.exit(1)

    print("ok")
