import argparse
import sys

from elyb.commands.init import runInit
from elyb.commands.ignore import runAddIgnore, runDelIgnore
from elyb.commands.build import runBuild
from elyb.commands.validate import runValidate
from elyb.commands.info import runInfo
from elyb.commands.clean import runClean
from elyb.commands.watch import runWatch


def buildParser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="elyb")
    subparsers = parser.add_subparsers(dest="command")

    initParser = subparsers.add_parser("init", help="initialize elyb in a plugin directory")
    initParser.add_argument("pluginRoot", metavar="plugin-root", help="path to plugin root directory")
    initParser.add_argument("--refmap", required=True, help="path to refmap.yml")
    initParser.add_argument("--outputdir", default="builds", help="output directory for builds (default: builds)")
    initParser.add_argument("--zipformat", default="zip", help="output file extension (default: zip)")

    bp = subparsers.add_parser("build", help="build plugin archive")
    bp.add_argument("--no-assets", action="store_true", help="exclude optionalAssets from archive")
    bp.add_argument("--compression", type=int, default=6, metavar="LEVEL", help="zip compression level 0-9 (default: 6)")
    bp.add_argument("--pass", dest="password", default=None, metavar="PASSWORD", help="encrypt archive with password")
    bp.add_argument("--additional", default=None, metavar="PATHS", help="comma-separated extra paths to include")
    bp.add_argument("--dry-run", action="store_true", help="list files that would be packed without building")

    subparsers.add_parser("validate", help="validate refmap, metainfo and settings")
    subparsers.add_parser("info", help="show current project info and build history")

    cp = subparsers.add_parser("clean", help="remove builds from outputDir")
    cp.add_argument("--duplicates-only", action="store_true", help="remove only duplicate builds")

    wp = subparsers.add_parser("watch", help="watch pluginRoot and rebuild on changes")
    wp.add_argument("--no-assets", action="store_true", help="exclude optionalAssets from archive")
    wp.add_argument("--compression", type=int, default=6, metavar="LEVEL", help="zip compression level 0-9 (default: 6)")
    wp.add_argument("--interval", type=int, default=2, metavar="SECONDS", help="poll interval in seconds (default: 2)")

    addIgnoreParser = subparsers.add_parser("add-ignore", help="add path to optionalAssets")
    addIgnoreParser.add_argument("path", help="path to add")

    delIgnoreParser = subparsers.add_parser("del-ignore", help="remove path from optionalAssets")
    delIgnoreParser.add_argument("path", help="path to remove")

    return parser


def main():
    parser = buildParser()
    args = parser.parse_args()

    if args.command == "init":
        runInit(args.pluginRoot, args.refmap, args.outputdir, args.zipformat)
        return

    if args.command == "build":
        additionalPaths = []
        if args.additional:
            additionalPaths = [p.strip() for p in args.additional.split(",") if p.strip()]
        runBuild(
            noAssets=args.no_assets,
            compression=args.compression,
            password=args.password,
            additionalPaths=additionalPaths,
            dryRun=args.dry_run,
        )
        return

    if args.command == "validate":
        runValidate()
        return

    if args.command == "info":
        runInfo()
        return

    if args.command == "clean":
        runClean(duplicatesOnly=args.duplicates_only)
        return

    if args.command == "watch":
        runWatch(
            noAssets=args.no_assets,
            compression=args.compression,
            interval=args.interval,
        )
        return

    if args.command == "add-ignore":
        runAddIgnore(args.path)
        return

    if args.command == "del-ignore":
        runDelIgnore(args.path)
        return

    parser.print_help()
    sys.exit(1)
