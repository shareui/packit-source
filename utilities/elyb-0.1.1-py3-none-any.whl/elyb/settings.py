import json
import os

import yaml

ELYB_DIR = ".elyb"
SETTINGS_FILE = "settings.json"


def getSettingsPath(cwd: str = ".") -> str:
    return os.path.join(cwd, ELYB_DIR, SETTINGS_FILE)


def findSettingsPath() -> str:
    # walk up from cwd until .elyb/settings.json is found
    current = os.path.abspath(".")
    while True:
        candidate = os.path.join(current, ELYB_DIR, SETTINGS_FILE)
        if os.path.isfile(candidate):
            return candidate
        parent = os.path.dirname(current)
        if parent == current:
            break
        current = parent
    raise FileNotFoundError(
        f"no {ELYB_DIR}/{SETTINGS_FILE} found in current or parent directories; run `elyb init` first"
    )


def readSettings(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def writeSettings(path: str, data: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


def loadRefmap(refmapPath: str) -> dict:
    with open(refmapPath, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def loadMeta(refmap: dict) -> tuple[str, dict]:
    metainfoPath = refmap.get("metainfo")
    if not metainfoPath:
        raise ValueError("'metainfo' key missing in refmap")
    with open(metainfoPath, "r", encoding="utf-8") as f:
        return metainfoPath, yaml.safe_load(f)
